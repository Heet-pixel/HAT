import bcrypt from 'bcryptjs';
import mongoose from 'mongoose';
import College from '../models/College.js';
import Department from '../models/Department.js';
import User from '../models/User.js';
import Student from '../models/Student.js';
import Subject from '../models/Subject.js';
import Course from '../models/Course.js';
import Notice from '../models/Notice.js';
import Attendance from '../models/Attendance.js';
import Mark from '../models/Mark.js';
import Schedule from '../models/Schedule.js';
import Syllabus from '../models/Syllabus.js';

export const live = { isDeleted: false };
export const idOf = value => value?._id || value;

export function roleIs(user, ...roles) {
  return roles.includes(user.role);
}

// Validates a profile-photo upload. Photos are stored as data URIs directly on
// the Student/User document (see model comments) rather than on local disk —
// deliberately, since this app must run on AWS EC2 without assuming a
// persistent/shared filesystem or any pre-configured S3 bucket. This keeps
// "one image reference" per person and needs zero extra infra to deploy.
// Validates a PDF attachment (syllabus document, announcement, notice).
// Same data-URI-in-MongoDB approach as photos (see validateImageDataUri) —
// no S3/disk needed, works on plain EC2. A higher size ceiling than photos
// since these are staff-uploaded documents, not something a phone camera
// produces casually — 5MB keeps a typical multi-page syllabus PDF well
// within MongoDB's 16MB document limit even after base64 overhead.
const MAX_PDF_BYTES = 5 * 1024 * 1024;
export function validatePdfDataUri(dataUri) {
  if (!dataUri || typeof dataUri !== 'string') throw badRequest('No PDF file was provided.');
  const match = /^data:application\/pdf;base64,([A-Za-z0-9+/=]+)$/.exec(dataUri.trim());
  if (!match) throw badRequest('Attachment must be a PDF file.');
  const approxBytes = Math.floor(match[1].length * 0.75);
  if (approxBytes > MAX_PDF_BYTES) {
    throw badRequest(`PDF is too large (max ${Math.floor(MAX_PDF_BYTES / 1024 / 1024)}MB). Please choose a smaller file.`);
  }
  if (approxBytes < 50) throw badRequest('PDF file appears to be empty or corrupted.');
  return dataUri.trim();
}

const MAX_AVATAR_BYTES = 100 * 1024; // 100KB raw image, per product requirement
export function validateImageDataUri(dataUri) {
  if (!dataUri || typeof dataUri !== 'string') throw badRequest('No image was provided.');
  const match = /^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/=]+)$/.exec(dataUri.trim());
  if (!match) throw badRequest('Image must be a JPEG, PNG, or WEBP file.');
  const base64 = match[2];
  const approxBytes = Math.floor(base64.length * 0.75);
  if (approxBytes > MAX_AVATAR_BYTES) {
    throw badRequest(`Image is too large (max ${Math.floor(MAX_AVATAR_BYTES / 1024)}KB). Please choose a smaller photo.`);
  }
  if (approxBytes < 100) throw badRequest('Image file appears to be empty or corrupted.');
  return dataUri.trim();
}

// Spec item 3: Emergency Contact Number — required (when supplied in an
// update), must be a plausible mobile number. Kept intentionally permissive
// on formatting (spaces/dashes/+country code) since this is a real-world
// contact number field, not a strict E.164 validator.
export function validateMobileNumber(value, fieldLabel = 'Emergency contact number') {
  const raw = String(value || '').trim();
  if (!raw) throw badRequest(`${fieldLabel} is required.`);
  const digits = raw.replace(/[\s\-()]/g, '');
  if (!/^\+?\d{10,15}$/.test(digits)) {
    throw badRequest(`${fieldLabel} must be a valid mobile number (10-15 digits).`);
  }
  return raw;
}

// Spec: a department may have at most one HOD and one Co-HOD at a time —
// used by both Admin's and Super Admin's "appoint HOD" endpoints so the rule
// is enforced identically regardless of who's appointing.
export async function appointHod({ dept, role, user }) {
  if (!['hod', 'co_hod'].includes(role)) throw badRequest('Role must be either HOD or Co-HOD.');
  const slotField = role === 'hod' ? 'hod' : 'coHod';
  const existingId = dept[slotField];
  if (existingId && String(existingId) !== String(user._id || user.id)) {
    const existing = await User.findOne({ _id: existingId, isDeleted: false }).select('name').lean();
    if (existing) {
      throw badRequest(`This department already has a ${role === 'hod' ? 'HOD' : 'Co-HOD'} (${existing.name}). Remove them first before appointing someone new.`);
    }
  }
  dept[slotField] = user._id || user.id;
  await dept.save();
  return dept;
}

// Detach whichever slot (hod/coHod) a user occupies on a department — called
// when that HOD/Co-HOD account is deleted, so the department doesn't keep
// pointing at a soft-deleted user.
export async function detachHodFromDepartment(userId, by) {
  await Department.updateMany({ hod: userId }, { $set: { hod: null, updatedBy: by } });
  await Department.updateMany({ coHod: userId }, { $set: { coHod: null, updatedBy: by } });
}

export async function ensureUser({ name, email, role, college, department, phone, subject, course, designation, qualification, experience, emergencyContact }, by) {
  const normalized = String(email || '').toLowerCase().trim();
  if (!normalized) throw Object.assign(new Error('Email is required.'), { status: 400 });
  let user = await User.findOne({ email: normalized }).select('+passwordHash');
  if (!user) {
    user = new User({ email: normalized, firstLogin: true, createdBy: by });
  }
  // Only update these fields if provided
  if (name) user.name = name;
  if (role) user.role = role;
  if (college) user.college = college;
  if (department !== undefined) user.department = department;
  if (phone) user.phone = phone;
  if (subject) user.subject = subject;
  if (course) user.course = course;
  if (designation) user.designation = designation;
  if (qualification) user.qualification = qualification;
  if (experience) user.experience = experience;
  if (emergencyContact) user.emergencyContact = emergencyContact;
  user.active = true;
  user.isDeleted = false;
  user.updatedBy = by;
  await user.save();
  return user;
}

export function mapStudent(s) {
  if (!s) return null;
  const o = s.toJSON ? s.toJSON() : { ...s };
  o.roll = o.roll || o.rollNo || o.rollNumber || '';
  o.rollNo = o.rollNo || o.roll || '';
  o.rollNumber = o.rollNumber || o.roll || o.rollNo || '';
  o.sem = o.sem || o.semester || 1;
  o.semester = o.semester || o.sem || 1;
  o.course = o.course || o.courseName || 'General';
  o.courseName = o.courseName || o.course;
  o.phone = o.phone || o.mobile || '';
  o.mobile = o.mobile || o.phone || '';
  o.active = o.active !== false && o.isActive !== false;
  o.isActive = o.active;
  if (typeof o.address === 'object' && o.address) {
    o.street = o.street || o.address.street || '';
    o.city = o.city || o.address.city || '';
    o.state = o.state || o.address.state || '';
    o.pincode = o.pincode || o.address.pincode || '';
  }
  o.status = o.isDeleted ? 'Deleted' : (o.status || (o.active !== false ? 'Active' : 'Inactive'));
  return o;
}

export function mapTeacher(t) {
  if (!t) return null;
  const o = t.toJSON ? t.toJSON() : { ...t };
  o.status = o.isDeleted ? 'Deleted' : (o.active !== false ? 'Active' : 'Inactive');
  o.designation = o.designation || (['hod', 'co_hod'].includes(o.role) ? 'HOD' : o.role === 'admin' ? 'Principal' : 'Teacher');
  return o;
}

export async function collegeScope(user) {
  if (roleIs(user, 'super_admin', 'superadmin')) return {};
  return { college: user.college };
}

export async function departmentScope(user) {
  if (roleIs(user, 'hod', 'co_hod', 'teacher')) return { college: user.college, department: user.department };
  return collegeScope(user);
}

export async function softDeleteMany(Model, filter, userId) {
  return Model.updateMany(filter, { $set: { isDeleted: true, active: false, deletedAt: new Date(), deletedBy: userId } });
}

function badRequest(message) {
  return Object.assign(new Error(message), { status: 400 });
}

// Spec item 1: Parent Email is mandatory, must be unique across students, and
// must differ from the student's own email. Enforced at the app layer (not a
// DB unique index) because this schema soft-deletes rather than removes rows —
// see the note on the Student model's parentEmail index.
export async function validateParentEmail({ parentEmail, studentEmail, excludeStudentId }) {
  const email = String(parentEmail || '').toLowerCase().trim();
  if (!email) throw badRequest('Parent email is required.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw badRequest('Parent email is not a valid email address.');
  if (studentEmail && email === String(studentEmail).toLowerCase().trim()) {
    throw badRequest('Parent email cannot be the same as the student email.');
  }
  const dupStudent = await Student.findOne({
    parentEmail: email, ...live,
    ...(excludeStudentId ? { _id: { $ne: excludeStudentId } } : {}),
  }).select('_id').lean();
  if (dupStudent) throw badRequest('This parent email is already in use for another student.');

  // Also block reusing an email that already belongs to a *different* account
  // (e.g. a teacher's login) — only exception is this exact student's own
  // existing parent account, which is fine to keep (no-op update).
  const dupUser = await User.findOne({ email, isDeleted: false }).select('role student').lean();
  if (dupUser && !(dupUser.role === 'parent' && excludeStudentId && String(dupUser.student || '') === String(excludeStudentId))) {
    throw badRequest('This email is already registered to another account.');
  }
  return email;
}

// Creates/updates the Parent login account for a student and keeps it pointed
// at the right email. If the student's parentEmail changed, the old parent
// account (if any) is detached rather than deleted, so nothing is destroyed —
// it simply stops granting access to this student's data.
export async function syncParentAccount(student, by) {
  await User.updateMany(
    { student: student._id, role: 'parent', email: { $ne: String(student.parentEmail || '').toLowerCase().trim() } },
    { $unset: { student: 1 }, $set: { updatedBy: by } }
  );
  if (!student.parentEmail) return null;
  const parent = await ensureUser({
    name: `Parent of ${student.name}`,
    email: student.parentEmail,
    role: 'parent',
    college: student.college,
    department: student.department,
  }, by);
  if (String(parent.student || '') !== String(student._id)) {
    parent.student = student._id;
    await parent.save();
  }
  return parent;
}

export async function createStudent(payload, user) {
  const roll = payload.roll || payload.rollNo || payload.rollNumber;
  if (!roll) throw badRequest('Roll number is required.');
  const isDepartmentRole = roleIs(user, 'hod', 'co_hod', 'teacher');
  const dept = isDepartmentRole ? user.department : (payload.department || payload.departmentId || user.department);
  const col = isDepartmentRole ? user.college : (payload.college || user.college);
  if (!col || !dept) throw Object.assign(new Error('College and department are required.'), { status: 400 });

  const course = payload.course || payload.courseName || 'General';
  const semester = Number(payload.semester || payload.sem || 1);

  // Spec item 9: no duplicate student records — a roll number must be unique
  // within its own class (college + department + course + semester).
  const dupRoll = await Student.findOne({
    college: col, department: dept, course, semester, ...live,
    roll: new RegExp(`^${String(roll).trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i'),
  }).select('_id').lean();
  if (dupRoll) throw badRequest(`Roll number "${roll}" is already in use in ${course} Semester ${semester}.`);

  const parentEmail = await validateParentEmail({ parentEmail: payload.parentEmail, studentEmail: payload.email });

  const address = typeof payload.address === 'object' && payload.address
    ? payload.address
    : {
        street: payload.street || payload.address || '',
        city: payload.city || '',
        state: payload.state || '',
        pincode: payload.pincode || ''
      };
  
  const student = await Student.create({
    ...payload,
    roll,
    rollNo: roll,
    rollNumber: roll,
    parentEmail,
    phone: payload.phone || payload.mobile || '',
    mobile: payload.mobile || payload.phone || '',
    course,
    courseName: payload.courseName || course,
    semester,
    sem: semester,
    address,
    city: payload.city || address.city || '',
    college: col,
    department: dept,
    createdBy: user.id || user._id
  });

  await syncParentAccount(student, user.id || user._id);

  if (payload.email) {
    const account = await ensureUser({
      name: payload.name,
      email: payload.email,
      role: 'student',
      college: student.college,
      department: student.department,
      phone: payload.phone
    }, user.id || user._id);
    student.user = account.id;
    account.student = student.id;
    await Promise.all([account.save(), student.save()]);
  }
  return student;
}

// Shared by HOD's and Admin's PUT /students/:id — validates & syncs the
// parent account only when parentEmail is actually part of the update, so
// routine edits (e.g. just changing a phone number) aren't forced to re-supply it.
export async function updateStudentAndSyncParent(filter, rawBody, by) {
  const existing = await Student.findOne(filter);
  if (!existing) return null;
  const body = { ...rawBody, updatedBy: by };
  if ('parentEmail' in body) {
    body.parentEmail = await validateParentEmail({
      parentEmail: body.parentEmail,
      studentEmail: body.email || existing.email,
      excludeStudentId: existing._id,
    });
  }
  const student = await Student.findOneAndUpdate(filter, body, { new: true });
  if (student && 'parentEmail' in body) {
    await syncParentAccount(student, by);
  }
  return student;
}

const defaultScheduleTimes = [
  ['10:30', '11:30'],
  ['11:30', '12:30'],
  ['12:30', '01:00'],
  ['02:00', '03:00'],
  ['03:00', '03:10'],
  ['03:10', '05:10']
];

function displayTime(startTime, endTime) {
  const to12 = value => {
    if (!value || !value.includes(':')) return value || '';
    let [hour, minute] = value.split(':').map(Number);
    const suffix = hour >= 12 ? 'PM' : 'AM';
    hour = hour % 12 || 12;
    return `${hour}:${String(minute).padStart(2, '0')} ${suffix}`;
  };
  return `${to12(startTime)}${endTime ? ' - ' + to12(endTime) : ''}`;
}

export async function normalizeSubjectPayload(payload, user) {
  const body = { ...payload };
  const dept = body.departmentId || body.department || user.department;
  let courseValue = body.courseName || body.course;

  if (courseValue) {
    const courseOr = [{ name: courseValue }, { code: courseValue }];
    if (mongoose.Types.ObjectId.isValid(courseValue)) courseOr.unshift({ _id: courseValue });
    const courseDoc = await Course.findOne({
      college: user.college,
      $or: courseOr,
      ...(dept ? { department: dept } : {})
    }).lean();
    if (courseDoc) {
      courseValue = courseDoc.name;
      body.courseId = courseDoc._id;
      body.totalSems = courseDoc.totalSems;
    }
  }

  body.course = courseValue || 'General';
  body.department = dept;
  body.semester = Number(body.semester || body.sem || 1);
  delete body.departmentId;
  return body;
}

export async function syncSubjectSchedule(subject, user) {
  if (!subject || subject.isDeleted) return null;
  const course = subject.course || 'General';
  const semester = Number(subject.semester || subject.sem || 1);
  const existing = await Schedule.findOne({
    college: subject.college,
    department: subject.department,
    course,
    semester,
    $or: [{ subject: subject._id }, { subjectName: subject.name }],
    ...live
  });

  const subjectCount = await Subject.countDocuments({
    college: subject.college,
    department: subject.department,
    course,
    semester,
    ...live
  });
  const idx = Math.max(0, subjectCount - 1) % defaultScheduleTimes.length;
  const [startTime, endTime] = existing
    ? [existing.startTime, existing.endTime]
    : defaultScheduleTimes[idx];
  const day = existing?.day || 'Mon';

  const teacher = subject.teacher
    ? await User.findById(subject.teacher).select('name').lean()
    : null;

  const update = {
    day,
    startTime,
    endTime,
    time: displayTime(startTime, endTime),
    subjectName: subject.name,
    subject: subject._id,
    teacherName: teacher?.name || existing?.teacherName || '',
    teacher: subject.teacher || existing?.teacher || null,
    room: existing?.room || '',
    type: subject.type || existing?.type || 'Lecture',
    course,
    semester,
    college: subject.college,
    department: subject.department,
    active: true,
    isDeleted: false,
    updatedBy: user.id || user._id
  };

  return Schedule.findOneAndUpdate(
    {
      college: subject.college,
      department: subject.department,
      course,
      semester,
      $or: [{ subject: subject._id }, { subjectName: subject.name }]
    },
    { $set: update, $setOnInsert: { createdBy: user.id || user._id } },
    { upsert: true, new: true }
  );
}

// ── Timetable: subject-locking & conflict detection ─────────────────────────
// These helpers back spec requirements:
//   5. Subjects must always come from the Admin-created master Subject list —
//      HOD/Teacher can never free-type a subject into a schedule or attendance record.
//   6. No two lectures may overlap for the same class, and no teacher may be
//      double-booked across overlapping time slots on the same day.

// Convert "HH:MM" (24h) to minutes-since-midnight for range comparisons.
function toMinutes(t) {
  if (!t || typeof t !== 'string' || !t.includes(':')) return null;
  const [h, m] = t.split(':').map(Number);
  if (Number.isNaN(h) || Number.isNaN(m)) return null;
  return h * 60 + m;
}

export function timesOverlap(aStart, aEnd, bStart, bEnd) {
  const as = toMinutes(aStart), ae = toMinutes(aEnd);
  const bs = toMinutes(bStart), be = toMinutes(bEnd);
  if (as == null || bs == null) return false;
  const aEndEff = ae != null ? ae : as + 1;
  const bEndEff = be != null ? be : bs + 1;
  return as < bEndEff && bs < aEndEff;
}

// Resolve a schedule slot's subject strictly against the Admin-created master
// Subject list. Never creates a subject — throws if no match is found, so a
// HOD/Teacher can never introduce a subject that Admin hasn't defined.
export async function resolveSubjectForSlot({ college, department, course, semester, subjectId, subjectName }) {
  let subject = null;
  if (subjectId && mongoose.Types.ObjectId.isValid(subjectId)) {
    subject = await Subject.findOne({ _id: subjectId, college, department, ...live });
  }
  if (!subject && subjectName) {
    subject = await Subject.findOne({
      college, department, ...live,
      name: new RegExp(`^${String(subjectName).trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i'),
      $or: [{ course }, { course: { $exists: false } }],
    });
  }
  if (!subject) {
    throw Object.assign(
      new Error(`"${subjectName || subjectId || 'Subject'}" is not in the Admin-created subject list for this course/semester. Ask Admin to add it first.`),
      { status: 400 }
    );
  }
  return subject;
}

// Look for a conflicting Schedule slot. Checks two things:
//   (a) class conflict — the same college/department/course/semester/day already
//       has an overlapping lecture (any teacher).
//   (b) teacher conflict — the given teacher already has an overlapping lecture
//       on that day, in any class.
// Returns a descriptive object if a conflict exists, otherwise null.
export async function findConflictingSlot({ college, department, course, semester, day, startTime, endTime, teacher, excludeId }) {
  const baseFilter = { college, ...live, day, ...(excludeId ? { _id: { $ne: excludeId } } : {}) };

  const classSlots = await Schedule.find({ ...baseFilter, department, course, semester })
    .populate('teacher', 'name').lean();
  for (const slot of classSlots) {
    if (timesOverlap(startTime, endTime, slot.startTime, slot.endTime)) {
      return {
        type: 'class',
        message: `This class already has a lecture scheduled during this time by ${slot.teacher?.name || slot.teacherName || 'another teacher'}.`,
      };
    }
  }

  if (teacher) {
    const teacherSlots = await Schedule.find({ ...baseFilter, teacher }).lean();
    for (const slot of teacherSlots) {
      if (timesOverlap(startTime, endTime, slot.startTime, slot.endTime)) {
        return {
          type: 'teacher',
          message: `This teacher already has a lecture scheduled during this time (${slot.course || ''} Sem ${slot.semester || ''}).`,
        };
      }
    }
  }

  return null;
}

// Spec: attendance marking must respect the same "no overlapping lecture for
// this class" rule as the timetable itself — if Teacher A already marked
// attendance for BCA Sem 2 Division A from 10:00-11:00, Teacher B cannot mark
// attendance for any overlapping window (10:15-12:15, or anything touching
// that range) for the same class/day, regardless of subject. This checks the
// actual Attendance records submitted, not just the Schedule, since a
// teacher's marking form takes a free-typed time that isn't required to
// exactly match a Schedule slot.
export async function findAttendanceTimeConflict({ college, department, course, semester, division, day, date, startTime, endTime, excludeTeacher }) {
  if (!startTime || !endTime) return null; // nothing to compare against
  const dayStart = new Date(date); dayStart.setHours(0, 0, 0, 0);
  const dayEnd = new Date(date); dayEnd.setHours(23, 59, 59, 999);
  const candidates = await Attendance.find({
    college, department, course, semester, ...live,
    division: division || '', date: { $gte: dayStart, $lte: dayEnd },
    ...(excludeTeacher ? { teacher: { $ne: excludeTeacher } } : {}),
  }).populate('teacher', 'name').select('time teacher subjectName').lean();
  for (const c of candidates) {
    if (!c.time) continue;
    const [cStart, cEnd] = String(c.time).split(/\s*[-–]\s*/);// attencde marked by another at this slot
    if (timesOverlap(startTime, endTime, cStart, cEnd)) {
      return { message: `${c.teacher?.name || 'Another teacher'} already has attendance marked for this class from ${cStart} to ${cEnd || ''}. No lecture may overlap another for the same class.` };
    }
  }
  return null;
}

export async function collegeSummary(collegeId) {
  const [departments, students, teachers, principals] = await Promise.all([
    Department.countDocuments({ college: collegeId, ...live }),
    Student.countDocuments({ college: collegeId, ...live }),
    User.countDocuments({ college: collegeId, role: { $in: ['teacher', 'hod', 'co_hod'] }, ...live }),
    User.countDocuments({ college: collegeId, role: { $in: ['admin', 'principal'] }, ...live })
  ]);
  return { departments, students, teachers, principals };
}

export async function adminOverview(user) {
  const scope = await collegeScope(user);
  const [departments, students, teachers, notices, hods] = await Promise.all([
    Department.countDocuments({ ...scope, ...live }),
    Student.countDocuments({ ...scope, ...live }),
    User.countDocuments({ ...scope, role: 'teacher', ...live }),
    Notice.countDocuments({ ...scope, ...live }),
    User.countDocuments({ ...scope, role: { $in: ['hod', 'co_hod'] }, ...live })
  ]);
  return { departments, students, teachers, hods, notices, users: teachers + students + hods };
}

export async function studentBundle(student) {
  const course = student.course || student.courseName;
  const semester = Number(student.semester || student.sem || 0);
  const filter = { college: student.college, department: student.department, ...live };
  const classFilter = {
    ...filter,
    ...(course ? { course } : {}),
    ...(semester ? { semester } : {})
  };
  const [subjects, notices, marks, timetable, syllabus, attendance] = await Promise.all([
    Subject.find(classFilter).lean(),
    Notice.find({
      college: student.college,
      ...live,
      $and: [
        { $or: [{ department: student.department }, { department: null }, { department: { $exists: false } }] },
        { $or: [
          { course: { $in: [null, undefined, ''] } },
          { course: student.course, semester: Number(student.semester || student.sem || 0) },
        ] },
      ],
    }).sort({ createdAt: -1 }).lean(),
    Mark.find({ student: student._id || student.id, ...live })
      .populate('subject', 'name code')
      .lean(),
    Schedule.find(classFilter).lean(),
    Syllabus.find(classFilter).lean(),
    Attendance.find({ student: student._id || student.id, ...live })
      .populate('subject', 'name code')
      .populate('teacher', 'name')
      .lean()
  ]);
  return { subjects, notices, marks, timetable, syllabus, attendance };
}

export async function hashDeletionPassword(password) {
  return bcrypt.hash(password, 12);
}

export async function compareDeletionPassword(password, hash) {
  if (!password || !hash) return false;
  return bcrypt.compare(password, hash);
}
